# Image-based-Human-Age-and-Gender-Estimation
Approach: Age estimation by first extracting Biologically Inspired Features(BIF), and then applying Kernel Partial Least Square Regression algorithm.
